# Design QA — 2026-09-02

## Visual truth and evidence

- Selected source: `generated_images/exec-09c461c3-4360-4aa4-88e7-4c0c48c3cb97.png`
- Normalized source: `docs/emerald-source-normalized.png` (450 × 450)
- Implementation capture: `docs/watchface-runtime-preview.png` (450 × 450)
- Full comparison: `docs/emerald-comparison.png` (900 × 450)
- Focused complications comparison: `docs/emerald-focus-comparison.png` (800 × 155)
- Animation evidence: `docs/emerald-animation-frames.png` (four decoded frames)
- State: active face, 10:08:32, 5 730 steps, 32% battery, clear alarm.

## Findings and fixes

| Priority | Finding | Resolution |
|---|---|---|
| P0 | Old circular recesses remained under the new ovals and made them look pasted on | Removed the two recesses from Emerald and Obsidian source textures; retained only the top icon circle |
| P0 | Previous glint could appear static | Replaced it with a real 27-frame animated WebP controlled by `PartAnimatedImage` and a repeating `AnimationController` |
| P0 | Alert state could be hidden by hands | Kept the alarm complication as the final scene layer; only the jewel is visible, while the full 56 × 56 area remains tappable |
| P1 | Installed typography differed from the concept | Bundled Manrope Light and SemiBold in every APK; no system font substitution |
| P1 | Values were small and optically unstable | Used fixed 150 × 88 symmetrical ovals with centered 31 px Manrope SemiBold text |
| P1 | Green status was too weak | Raised clear-state jewel to vivid `#00F58A` with a white edge |
| P1 | Dial left a visible gap at the physical edge | Active and ambient dial textures overscan the 450 × 450 canvas by 8 px on every side |
| P2 | Glint was too white and cheap-looking | Limited the animated layer to 36–41% scene alpha; preserved emerald/champagne, obsidian/platinum, and sapphire/ice palettes |

## Verification

- Full comparison and focused comparison were inspected after the final fix.
- The decoded animation frame 0 vs. frame 14 differs by 190,369 pixels, confirming non-static bitmap content.
- All three WFF XML files pass the official Watch Face Format v4 XSD validator.
- APK package metadata, ZIP integrity, alignment, and APK Signature Scheme v3 were verified.
- No Android device is connected to this workspace, so final AMOLED brightness and motion acceptance remain an on-watch check.

**Final result: passed for build and design QA; physical-device motion check pending.**
