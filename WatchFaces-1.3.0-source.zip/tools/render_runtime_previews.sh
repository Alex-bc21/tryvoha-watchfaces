#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")/.." && pwd)"
tmp_root="$(mktemp -d)"
trap 'rm -rf "$tmp_root"' EXIT

earbuds_icon="/usr/share/icons/Adwaita/scalable/devices/audio-headphones.svg"

render_hand() {
    local source="$1" size="$2" x="$3" y="$4" angle="$5" output="$6"
    convert -size 450x450 xc:none \
        \( "$source" -resize "${size}x${size}!" \) -geometry "+${x}+${y}" -composite \
        -virtual-pixel transparent -distort SRT "225,225 ${angle}" \
        -gravity center -crop 450x450+0+0 +repage "$output"
}

render_analog() {
    local module="$1" accent="$2" inner="$3" text_color="$4" overlay="$5"
    local res="$project_root/$module/src/main/res/drawable-nodpi"
    local font="$project_root/$module/src/main/res/font/manrope_semibold.ttf"
    local work="$tmp_root/$module"
    mkdir -p "$work"

    # This matches the WFF active scene: 466 px overscan, tint, and a mid-cycle shimmer frame.
    convert "$res/dial_active.png" -resize 466x466! -gravity center -crop 450x450+0+0 +repage "$work/base.png"
    convert -size 450x450 xc:none -fill "$overlay" -draw 'circle 225,225 225,0' "$work/tint.png"
    convert "$work/base.png" "$work/tint.png" -composite "$work/base_tinted.png"
    convert "$res/dial_shimmer.webp[14]" -coalesce -background none -gravity northwest -extent 450x450 \
        -channel A -evaluate multiply 0.41 +channel "$work/shimmer.png"
    convert "$work/base_tinted.png" "$work/shimmer.png" -composite "$work/scene.png"

    convert "$work/scene.png" \
        -fill '#00160FF0' -stroke "$accent" -strokewidth 2.2 \
        -draw 'roundrectangle 35,178 185,266 44,44' \
        -draw 'roundrectangle 265,178 415,266 44,44' \
        -fill none -stroke "$inner" -strokewidth 1 \
        -draw 'roundrectangle 39,182 181,262 40,40' \
        -draw 'roundrectangle 269,182 411,262 40,40' \
        -fill '#00160FD9' -stroke "$accent" -strokewidth 1.5 \
        -draw 'roundrectangle 174,294 276,336 8,8' \
        "$work/surfaces.png"

    inkscape "$earbuds_icon" --export-type=png --export-filename="$work/earbuds-source.png" \
        --export-width=128 --export-height=128 >/dev/null 2>&1
    convert "$work/earbuds-source.png" -filter Lanczos -resize 51x51 -alpha set \
        -channel RGB -fill '#FFE8B8' -colorize 100 +channel "$work/earbuds.png"
    convert "$work/surfaces.png" "$work/earbuds.png" -gravity northwest -geometry +200+104 -composite \
        -font "$font" -fill "$text_color" -stroke none \
        -gravity center -pointsize 31 -annotate -115+2 '5 730' -annotate +115+2 '32%' \
        -pointsize 22 -annotate +0+90 '2.09' "$work/info.png"

    render_hand "$res/hour_hand.png" 230 110 74 304 "$work/hour.png"
    render_hand "$res/minute_hand.png" 245 102 52 48 "$work/minute.png"
    render_hand "$res/second_hand.png" 390 30 31 192 "$work/second.png"

    convert "$work/info.png" "$work/hour.png" -composite "$work/minute.png" -composite "$work/second.png" -composite \
        -fill '#FFFFFFFF' -stroke none -draw 'circle 225,365 236,365' \
        -fill '#00F58AFF' -draw 'circle 225,365 234,365' \
        "$work/final-450.png"

    cp "$work/final-450.png" "$project_root/docs/${module}-runtime-preview.png"
    convert "$work/final-450.png" -resize 1254x1254! "$res/preview.png"
}

render_sapphire() {
    local module="sapphire"
    local res="$project_root/$module/src/main/res/drawable-nodpi"
    local light="$project_root/$module/src/main/res/font/manrope_light.ttf"
    local semibold="$project_root/$module/src/main/res/font/manrope_semibold.ttf"
    local work="$tmp_root/$module"
    mkdir -p "$work"

    convert "$res/dial_active.png" -resize 466x466! -gravity center -crop 450x450+0+0 +repage "$work/base.png"
    convert -size 450x450 xc:none -fill '#00091724' -draw 'circle 225,225 225,0' "$work/tint.png"
    convert "$res/dial_shimmer.webp[14]" -coalesce -background none -gravity northwest -extent 450x450 \
        -channel A -evaluate multiply 0.41 +channel "$work/shimmer.png"
    convert "$work/base.png" "$work/tint.png" -composite "$work/shimmer.png" -composite \
        -font "$semibold" -stroke none -gravity center \
        -fill '#BBD9FF' -pointsize 22 -annotate +0-112 'СР 2.09' \
        -font "$light" -fill '#F5FAFF' -pointsize 112 -annotate +0-28 '10 08' \
        -fill '#45B9FF6B' -draw 'circle 225,179 236,179' -draw 'circle 225,221 236,221' \
        -fill '#B9FFFF58' -draw 'circle 225,179 231,179' -draw 'circle 225,221 231,221' \
        -fill '#0A172BC8' -stroke '#C6EFFF8E' -strokewidth 1.5 \
        -draw 'roundrectangle 42,269 208,327 29,29' -draw 'roundrectangle 242,269 408,327 29,29' \
        -font "$semibold" -fill '#EAF4FF' -stroke none -pointsize 29 \
        -annotate -100+73 '5 730' -annotate +100+73 '32%' \
        -fill '#FFFFFFFF' -draw 'circle 225,346 236,346' \
        -fill '#00F58AFF' -draw 'circle 225,346 234,346' \
        "$work/final-450.png"

    cp "$work/final-450.png" "$project_root/docs/${module}-runtime-preview.png"
    convert "$work/final-450.png" -resize 1254x1254! "$res/preview.png"
}

render_analog "watchface" '#C99765D6' '#4FF0B470' '#FFF4DB' '#00110B32'
render_analog "obsidian" '#AEB7C3C8' '#72CFE870' '#FFF7EC' '#00000042'
render_sapphire

source_reference="$project_root/../../generated_images/exec-09c461c3-4360-4aa4-88e7-4c0c48c3cb97.png"
convert "$source_reference" -crop 660x660+140+535 +repage -resize 450x450! "$project_root/docs/emerald-source-normalized.png"
convert "$project_root/docs/emerald-source-normalized.png" "$project_root/docs/watchface-runtime-preview.png" +append "$project_root/docs/emerald-comparison.png"

echo "Runtime previews rendered."
