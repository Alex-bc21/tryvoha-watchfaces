#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")/.." && pwd)"
work_dir="$(mktemp -d)"
trap 'rm -r "$work_dir"' EXIT

make_shimmer() {
  local module="$1"
  local broad="$2"
  local bright="$3"
  local accent="$4"
  local output_dir="$project_root/$module/src/main/res/drawable-nodpi"
  local frames_dir="$work_dir/$module-shimmer"
  mkdir -p "$frames_dir"

  for frame in $(seq 0 31); do
    local x=$(( -210 + frame * 28 ))
    local x2=$(( x + 92 ))
    local x3=$(( x + 20 ))
    local x4=$(( x + 54 ))
    convert -size 450x450 xc:none \
      -fill "$broad" -draw "polygon $x,-120 $x2,-120 $((x2-250)),570 $((x-250)),570" \
      -blur 0x30 \
      "$frames_dir/broad.png"
    convert -size 450x450 xc:none \
      -fill "$bright" -draw "polygon $x3,-120 $x4,-120 $((x4-250)),570 $((x3-250)),570" \
      -blur 0x11 \
      "$frames_dir/bright.png"
    convert -size 450x450 xc:none \
      -fill "$accent" -draw "ellipse 225,225 160,105 0,360" \
      -blur 0x22 \
      "$frames_dir/accent.png"
    convert "$frames_dir/broad.png" "$frames_dir/bright.png" -compose screen -composite \
      "$frames_dir/accent.png" -compose screen -composite \
      "$frames_dir/frame_$(printf '%03d' "$frame").png"
  done

  ffmpeg -hide_banner -loglevel error -y \
    -framerate 8 -i "$frames_dir/frame_%03d.png" \
    -loop 0 -c:v libwebp_anim -lossless 0 -q:v 76 -pix_fmt yuva420p \
    "$output_dir/dial_shimmer.webp"
  cp "$frames_dir/frame_016.png" "$output_dir/dial_shimmer_thumb.png"
}

make_alert_pulse() {
  local output_dir="$1"
  local frames_dir="$work_dir/alert-pulse"
  mkdir -p "$frames_dir"

  for frame in $(seq 0 23); do
    local radius=$(( 10 + frame * 18 / 23 ))
    local alpha=$(( 145 - frame * 130 / 23 ))
    convert -size 56x56 xc:none \
      -fill "rgba(255,36,61,$alpha)" \
      -draw "circle 28,28 $((28+radius)),28" \
      -blur 0x3 \
      "$frames_dir/frame_$(printf '%03d' "$frame").png"
  done

  ffmpeg -hide_banner -loglevel error -y \
    -framerate 12 -i "$frames_dir/frame_%03d.png" \
    -loop 0 -c:v libwebp_anim -lossless 0 -q:v 82 -pix_fmt yuva420p \
    "$output_dir/alert_pulse.webp"
  cp "$frames_dir/frame_000.png" "$output_dir/alert_pulse_thumb.png"
}

make_shimmer watchface 'rgba(229,181,92,0.10)' 'rgba(255,239,194,0.22)' 'rgba(0,180,106,0.035)'
make_shimmer obsidian 'rgba(174,208,236,0.09)' 'rgba(239,248,255,0.20)' 'rgba(67,140,220,0.035)'
make_shimmer sapphire 'rgba(40,104,255,0.10)' 'rgba(154,224,255,0.24)' 'rgba(70,44,210,0.045)'

for module in watchface obsidian sapphire; do
  make_alert_pulse "$project_root/$module/src/main/res/drawable-nodpi"
done
