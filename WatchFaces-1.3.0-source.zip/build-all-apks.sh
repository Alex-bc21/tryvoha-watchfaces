#!/usr/bin/env bash
set -euo pipefail

TASK_ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then
  TASK_SDK="$ANDROID_SDK_ROOT"
elif [[ -d "$TASK_ROOT/../android-sdk" ]]; then
  TASK_SDK="$TASK_ROOT/../android-sdk"
else
  TASK_SDK="$TASK_ROOT/../../android-sdk"
fi
TASK_TOOLS="$TASK_SDK/build-tools/36.0.0"
TASK_PLATFORM="$TASK_SDK/platforms/android-36/android.jar"
TASK_KEY="$TASK_ROOT/signing/emerald-vault.keystore"
TASK_RELEASE="$TASK_ROOT/release"

mkdir -p "$TASK_RELEASE" "$TASK_ROOT/signing"

if [[ ! -f "$TASK_KEY" ]]; then
  keytool -genkeypair -v \
    -keystore "$TASK_KEY" \
    -storepass android -keypass android \
    -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Premium Watch Faces, O=Local Build, C=UA" -noprompt >/dev/null
fi

build_face() {
  local module="$1"
  local apk_name="$2"
  local version_code="$3"
  local version_name="$4"
  local build_dir="$TASK_ROOT/$module/build/manual"
  local output="$TASK_RELEASE/$apk_name-$version_name.apk"

  mkdir -p "$build_dir/compiled"
  rm -f "$build_dir/compiled/resources.zip" "$build_dir/app-unsigned-unaligned.apk" "$build_dir/app-unsigned.apk" "$output"

  "$TASK_TOOLS/aapt2" compile \
    --dir "$TASK_ROOT/$module/src/main/res" \
    -o "$build_dir/compiled/resources.zip"

  "$TASK_TOOLS/aapt2" link \
    -I "$TASK_PLATFORM" \
    --manifest "$TASK_ROOT/$module/src/main/AndroidManifest.xml" \
    --min-sdk-version 36 \
    --target-sdk-version 36 \
    --version-code "$version_code" \
    --version-name "$version_name" \
    -o "$build_dir/app-unsigned-unaligned.apk" \
    "$build_dir/compiled/resources.zip"

  "$TASK_TOOLS/zipalign" -f -p 4 "$build_dir/app-unsigned-unaligned.apk" "$build_dir/app-unsigned.apk"

  "$TASK_TOOLS/apksigner" sign \
    --ks "$TASK_KEY" \
    --ks-key-alias androiddebugkey \
    --ks-pass pass:android \
    --key-pass pass:android \
    --out "$output" \
    "$build_dir/app-unsigned.apk"

  "$TASK_TOOLS/apksigner" verify --verbose "$output" >/dev/null
  printf '%s\n' "$output"
}

build_face watchface EmeraldVaultWatchFace 4 1.3.0
build_face obsidian ObsidianPrismWatchFace 3 1.2.0
build_face sapphire SapphireFlowWatchFace 3 1.2.0
