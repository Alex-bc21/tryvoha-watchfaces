# Validation status — 2026-09-02

## Passed locally

- Android SDK Platform 36 and Build Tools 36.0.0 are installed and verified.
- Official `google/watchface` XSD validator: all three faces pass Watch Face Format version 4.
- Animated assets decode as 27 distinct WebP frames; frame 0 vs. frame 14 differs by 190,369 pixels.
- Each active animation uses `PartAnimatedImage` plus a repeating `AnimationController` and is disabled in AOD.
- Manrope Light and SemiBold are bundled as application font resources in all three APKs.
- Each APK is aligned, ZIP-clean, signed, and verified with APK Signature Scheme v3.
- Package IDs and version metadata match the release filenames.
- All releases use the same certificate SHA-256: `437d2f740fa07f9a93b9fe284a6dd8e31c4aecaa548c66164fdd547db591a7d9`.
- Alarm status is the last scene layer and cannot be hidden by analog hands.
- No heart-rate, calorie, sunrise, or sunset data source is present.

## Device acceptance check

No watch is connected to ADB in this workspace. After installation, verify visible glint motion for at least 10 seconds, wrist-tilt parallax, taps, AOD, Samsung provider icon rendering, and alarm-state transitions on the physical watch.

## Official implementation references

- [Watch Face Format overview](https://developer.android.com/training/wearables/wff)
- [Animated images](https://developer.android.com/training/wearables/wff/transform/images)
- [Animation controller](https://developer.android.com/reference/wear-os/wff/group/part/animated-image/animation-controller)
- [Custom fonts](https://developer.android.com/training/wearables/wff/text)
- [Complications](https://developer.android.com/training/wearables/wff/complications)
- [Official validator](https://github.com/google/watchface)
