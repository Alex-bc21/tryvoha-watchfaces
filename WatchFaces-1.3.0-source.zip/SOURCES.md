# Official implementation references

- [Watch Face Format overview](https://developer.android.com/training/wearables/wff)
- [Create a Watch Face Format project](https://developer.android.com/training/wearables/wff/build)
- [Analog time elements](https://developer.android.com/training/wearables/wff/time)
- [Complications](https://developer.android.com/training/wearables/wff/complications)
- [Default provider policy](https://developer.android.com/reference/wear-os/wff/complication/default-provider-policy)
- [Dynamic transforms](https://developer.android.com/training/wearables/wff/transform)
- [Animated images](https://developer.android.com/training/wearables/wff/transform/images)
- [Animation controller](https://developer.android.com/reference/wear-os/wff/group/part/animated-image/animation-controller)
- [Custom fonts](https://developer.android.com/training/wearables/wff/text)
- [Official WFF validator](https://github.com/google/watchface)
- [Official SimpleAnalog sample](https://github.com/android/wear-os-samples/tree/main/WatchFaceFormat/SimpleAnalog)
