#!/usr/bin/env bash
set -euo pipefail

TASK_ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then
  TASK_SDK="$ANDROID_SDK_ROOT"
elif [[ -d "$TASK_ROOT/../android-sdk" ]]; then
  TASK_SDK="$TASK_ROOT/../android-sdk"
else
  TASK_SDK="$TASK_ROOT/../../android-sdk"
fi
TASK_BUILD="$TASK_ROOT/watchface/build/manual"
TASK_TOOLS="$TASK_SDK/build-tools/36.0.0"
TASK_PLATFORM="$TASK_SDK/platforms/android-36/android.jar"
TASK_KEY="$TASK_ROOT/signing/emerald-vault.keystore"
TASK_OUTPUT="$TASK_ROOT/release/EmeraldVaultWatchFace-1.3.0.apk"

mkdir -p "$TASK_BUILD/compiled" "$(dirname "$TASK_OUTPUT")" "$TASK_ROOT/signing"
rm -f "$TASK_BUILD/compiled/resources.zip" "$TASK_BUILD/app-unsigned-unaligned.apk" "$TASK_BUILD/app-unsigned.apk" "$TASK_OUTPUT"

"$TASK_TOOLS/aapt2" compile \
  --dir "$TASK_ROOT/watchface/src/main/res" \
  -o "$TASK_BUILD/compiled/resources.zip"

"$TASK_TOOLS/aapt2" link \
  -I "$TASK_PLATFORM" \
  --manifest "$TASK_ROOT/watchface/src/main/AndroidManifest.xml" \
  --min-sdk-version 36 \
  --target-sdk-version 36 \
  --version-code 4 \
  --version-name 1.3.0 \
  -o "$TASK_BUILD/app-unsigned-unaligned.apk" \
  "$TASK_BUILD/compiled/resources.zip"

"$TASK_TOOLS/zipalign" -f -p 4 \
  "$TASK_BUILD/app-unsigned-unaligned.apk" "$TASK_BUILD/app-unsigned.apk"

if [[ ! -f "$TASK_KEY" ]]; then
  keytool -genkeypair -v \
    -keystore "$TASK_KEY" \
    -storepass android -keypass android \
    -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Emerald Vault, O=Local Build, C=UA" -noprompt >/dev/null
fi

"$TASK_TOOLS/apksigner" sign \
  --ks "$TASK_KEY" \
  --ks-key-alias androiddebugkey \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$TASK_OUTPUT" \
  "$TASK_BUILD/app-unsigned.apk"

"$TASK_TOOLS/apksigner" verify --verbose "$TASK_OUTPUT"
printf '%s\n' "$TASK_OUTPUT"
